import React from 'react';
import './Find.css';
import '../Components/Button.module.css';
import exIcon from '../image/exIcon.png';

export default function Find() {
  return (
    <div className="sectionF">
      <div className="pageF">
        <div className="iconWrapF">
          <img src={exIcon} className="icon" alt="icon" />
        </div>
        <div className="contentF">
          <div className="titleF">계정찾기</div>
          <form action="http://cap.dothome.co.kr/passwordre.php" method="POST">
            <div style={{ marginTop: '70px' }} className="inputWrapF">
              <input className="inputF" placeholder="id" name="id" id='id'/>
            </div>
            <div className="inputWrapF">
              <input className="inputF" placeholder="email" name="email" id='email'/>
            </div>
            <button class="buttonF">찾기</button> 
          </form>
        </div>
      </div>
    </div>
  );
}
