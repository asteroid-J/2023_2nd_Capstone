import React, { useState } from 'react';
import './Signup.css';
import '../Components/Button.module.css';
import exIcon from '../image/exIcon.png';

export default function Signup() {
  const [userid, setUserid] = useState('');

  const handleUserid = (e) => {
    setUserid(e.target.value);
  };
  
  return (
    <div className="sectionS">
      <div className="pageS">
        <div className="iconWrapS">
          <img src={exIcon} className="icon" alt="icon" />
        </div>
        <div className="contentS">
          <div className="titleS">Signup</div>
          <form action="http://cap.dothome.co.kr/SignUp.php" method="POST">
            <div className="inputContainerS">
              <div className="inputContentS">
                <div style={{ marginTop: '70px' }} className="inputWrapS">
                  <input
                    className="inputS"
                    onChange={handleUserid}
                    value={userid}
                    placeholder="ID"
                    name="id"
                    id='id' 
                    
                  />
                </div>
                <div className="inputWrapS">
                  <input className="inputS" placeholder="PASSWORD" name="pw" id='pw' type='password'/>
                </div>
                <div className="inputWrapS">
                  <input className="inputS" placeholder="전화번호" name="CODE"  />
                </div>
              </div>
              <div className="inputContentS">
                <div style={{ marginTop: '70px' }} className="inputWrapS">
                  <input className="inputS" placeholder="NAME" name="name" id='name' />
                </div>
                <div className="inputWrapS">
                  <input className="inputS" placeholder="학번" name="classnum" id='classnum'/>
                </div>
                <div className="inputWrapS">
                  <input className="inputS" placeholder="EMAIL" name="email" id='email' />
                </div>
              </div>
            </div>
            <button class="buttonS">회원가입</button> 
           </form>
        </div>
      </div>
      <div className="guideS">
        <p>
          면접 전, 면접 관들이 할 질문들을 미리 생각해서 대비 하는것이 좋습니다.
        </p>
      </div>
    </div>
  );
}
